<?php

// $host = 'localhost';
// $db= '';
// $user = 'root';
// $pass='';
// $charset='utf8md4';

// $options= [
//     PDO :: ATTR_ERRMODE => PDO :: ERRMODE_EXCEPTION,
//     PDO :: ATTR_DEFAULT_FETCH_MODE => PDO :: FECH_ASSOC,
//     PDO :: ATTR_EMULATE_PREPARES => false,
// ];
// $dsn="mysql:host=$host;dbname=$db;charset=$charset";

// try {
//     $pdo= new PDO($dsn, $user,$pass,$options);
// } catch(PDOexception $e){
//     die ("error en la conexion con la base de datos" . $e ->get_message());
// }

$conexion = mysqli_connect(
"localhost",
"root",
"",
"restaurante"
);
if (!$conexion) {
die("No se pudo conectar con la base de datos.");
}
mysqli_set_charset($conexion, "utf8mb4");
?>