<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
<link rel="stylesheet" href="/restaurante/css/style.css">
<meta charset="UTF-8">
<title>Login</title>
</head>
<body>
    <center><h2>Iniciar sesión</h2></center>

<div class = "contenedor_login">
<form action="ValidarLogin.php" method="POST">

    <label>Usuario:</label>
    <input type="text" name="usuario" maxlength="30" required>
    <br><br>
    <label>Contraseña:</label>
    <input type="password" name="password" required>
    <br><br>
    <button type="submit">Ingresar</button>

</form>
</div>
    <br>
    <center><a href="registro.html">Crear cuenta</a></center>
    </body>
</html>