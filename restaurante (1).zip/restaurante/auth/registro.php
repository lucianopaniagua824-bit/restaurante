<?php

// auth/registro.php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/restaurante/css/style.css">
    <title>Trillinger</title>
</head>
<body>

<div class="contenedor_auth">
<form action="procesar_registro.php" method="post">

    <label for="Nombre">Nombre Completo:</label>
    <input name ="usuario" type="text" placeholder="por ej:luchito" requiered>
    <br> <br>
    <label for="correo">mail:</label>
    <input name ="email" type="email" placeholder= "por ej: email@gmail.com" requiered>
    <br> <br>
    <label for="Contraseña">Contreseña:</label>
    <input name ="password" type="password" placeholder="ingrese su Contreseña" required>
    <br> <br>
<button type="submit" id = "registro_bot" >Registrarse</button
>
<P>¿Ya tenes cuenta? <a href="login.php">inicia sesion</a> </p>

</form>

</div>    

</body>
</html>