<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
header("Location: login.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="/restaurante/css/style.css">
<title>Inicio</title>
</head>
<body>
<center>
<h1>
Bienvenido
<?php
echo htmlspecialchars(
$_SESSION["usuario"]
);
?>
</h1>
</center>
<center><p>Esta página requiere una sesión iniciada.</p></center>
<center><a href="logout.php">Cerrar sesión</a></center>
</body>
</html>