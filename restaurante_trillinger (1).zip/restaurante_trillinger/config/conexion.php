<?php
$conexion = mysqli_connect(
"localhost",
"root",
"",
"restaurante"
);
if (!$conexion) {
die("No se pudo conectar con la base de datos.");
}
mysqli_set_charset($conexion, "utf8mb4");
?>