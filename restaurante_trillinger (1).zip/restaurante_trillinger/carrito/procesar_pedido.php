<?php
session_start();
require_once("../config/conexion.php");

$usuario_id   = (int) $_SESSION['id_usuario'];
$tipo_entrega = $_POST['tipo_entrega'];
$direccion = trim($_POST['direccion'] ?? '');

if ($tipo_entrega != "en_mesa" && $tipo_entrega != "delivery") {
    die("Tipo de entrega inválido");
}

if ($tipo_entrega == "delivery" && $direccion == "") {
    die("Tenés que ingresar una dirección para el delivery");
}

if ($tipo_entrega == "en_mesa") {
    $direccion = "";
}

$direccion = mysqli_real_escape_string($conexion, $direccion);

$resultado = mysqli_query($conexion, "SELECT id FROM carrito WHERE usuario_id = '$usuario_id'");
$carrito = mysqli_fetch_assoc($resultado);

if (!$carrito) {
    die("Tu carrito está vacío");
}
$id_carrito = $carrito['id'];

$cons_sql = "SELECT id_plato, COUNT(*) AS cantidad FROM detalle_carrito WHERE id_carrito = '$id_carrito' GROUP BY id_plato";

$detalles = mysqli_query($conexion, $cons_sql);

$items = [];
$total = 0;

while ($detalle = mysqli_fetch_assoc($detalles)) {
    $id_plato = $detalle['id_plato'];

    $res_plato = mysqli_query($conexion, "SELECT precio FROM platos WHERE id = '$id_plato'");
    $plato = mysqli_fetch_assoc($res_plato);

    $items[] = [
        'id_plato' => $id_plato,
        'cantidad' => $detalle['cantidad'],
        'precio'   => $plato['precio']
    ];

    $total += $plato['precio'] * $detalle['cantidad'];
}

if (empty($items)) {
    die("Tu carrito está vacío");
}

mysqli_query($conexion, "INSERT INTO pedidos (usuario_id, total, tipo_entrega, direccion) VALUES ($usuario_id, $total, '$tipo_entrega', '$direccion')");
$pedido_id = mysqli_insert_id($conexion);

foreach ($items as $item) {
    $id_plato = $item['id_plato'];
    $cantidad = $item['cantidad'];
    $precio   = $item['precio'];

$cons_sql = "INSERT INTO detalle_pedido (pedido_id, plato_id, cantidad, precio_unitario) VALUES ($pedido_id, $id_plato, $cantidad, $precio)";
    mysqli_query($conexion,$cons_sql);
}

mysqli_query($conexion, "DELETE FROM detalle_carrito WHERE id_carrito = '$id_carrito'");

header("Location: mis_pedidos.php");
exit();
?>