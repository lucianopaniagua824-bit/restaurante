<?php
session_start();
require_once("../config/conexion.php");

$usuario_id = (int) $_SESSION['id_usuario'];
$plato_id   = (int) $_POST['plato_id'];
$cantidad   = (int) $_POST['cantidad'];

$resultado = mysqli_query($conexion, "SELECT id FROM carrito WHERE usuario_id = $usuario_id");
$carrito = mysqli_fetch_assoc($resultado);

if ($carrito) {
    $id_carrito = $carrito['id'];
} else {
    mysqli_query($conexion, "INSERT INTO carrito (usuario_id) VALUES ($usuario_id)");
    $id_carrito = mysqli_insert_id($conexion);
}


for ($i = 0; $i < $cantidad; $i++) {
    mysqli_query($conexion, "INSERT INTO detalle_carrito (id_carrito, id_plato) VALUES ($id_carrito, $plato_id)");
}

echo "ok";
?>