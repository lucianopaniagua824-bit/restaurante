<?php
session_start();
require_once("../config/conexion.php");

$usuario_id = (int) $_SESSION['id_usuario'];
$id_plato   = (int) $_POST['id_plato'];

$resultado = mysqli_query($conexion, "SELECT id FROM carrito WHERE usuario_id = $usuario_id");
$carrito = mysqli_fetch_assoc($resultado);

if ($carrito) {
    $id_carrito = $carrito['id'];

    mysqli_query($conexion, "DELETE FROM detalle_carrito WHERE id_carrito = $id_carrito AND id_plato = $id_plato");
    echo "ok";
} else {
    echo "error";
}
?>