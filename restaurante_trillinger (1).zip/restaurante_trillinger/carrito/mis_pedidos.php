<?php
session_start();
require_once("../config/conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../html/login.html");
    exit();
}

$usuario_id = (int) $_SESSION['id_usuario'];

$pedidos = mysqli_query($conexion, "SELECT * FROM pedidos WHERE usuario_id = '$usuario_id' ORDER BY fecha_pedido DESC");
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis pedidos - Trillinger</title>
    <link rel="stylesheet" href="../css/carrito.css">
</head>
<body>

    <header class="top-nav">
        <div class="nav-content">
            <h2 class="logo-text">Trillinger</h2>
            <a href="../auth/inicio.php">← Volver a la carta</a>
        </div>
    </header>

    <main class="contenedor">
        <h1>Mis pedidos</h1>
        <p class="subtitulo">El historial de lo que pediste.</p>

        <?php if (mysqli_num_rows($pedidos) == 0): ?>
            <p class="vacio">Todavía no hiciste ningún pedido.</p>
        <?php endif; ?>

        <?php while ($pedido = mysqli_fetch_assoc($pedidos)): ?>
            <div class="pedido">
                <div class="pedido-cabecera">
                    <h3>Pedido #<?php echo $pedido['id']; ?></h3>
                    <span class="estado estado-<?php echo $pedido['estado']; ?>">
                        <?php echo str_replace('_', ' ', $pedido['estado']); ?>
                    </span>
                </div>

                <p class="pedido-info">
                    <?php echo $pedido['fecha_pedido']; ?> ·
                    <?php echo ($pedido['tipo_entrega'] == 'delivery') ? 'Delivery' : 'En mesa'; ?>
                </p>

                <?php if ($pedido['tipo_entrega'] == 'delivery'): ?>
                    <p class="pedido-info">Dirección: <?php echo htmlspecialchars($pedido['direccion']); ?></p>
                <?php endif; ?>

                <ul>
                    <?php
                    $pedido_id = $pedido['id'];
                    $detalles = mysqli_query($conexion, "SELECT * FROM detalle_pedido WHERE pedido_id = '$pedido_id'");

                    while ($detalle = mysqli_fetch_assoc($detalles)) {
                        $id_plato = $detalle['plato_id'];
                        $res_plato = mysqli_query($conexion, "SELECT nombre FROM platos WHERE id = '$id_plato'");
                        $plato = mysqli_fetch_assoc($res_plato);

                        $subtotal = $detalle['precio_unitario'] * $detalle['cantidad'];
                        echo "<li><span>" . htmlspecialchars($plato['nombre']) . " x" . $detalle['cantidad'] . "</span><span>$" . $subtotal . "</span></li>";
                    }
                    ?>
                </ul>

                <div class="pedido-total">Total: $<?php echo $pedido['total']; ?></div>
            </div>
        <?php endwhile; ?>
    </main>

</body>
</html>