<?php
session_start();
require_once("../config/conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../html/login.html");
    exit();
}

$usuario_id = (int) $_SESSION['id_usuario'];

$platos_carrito = [];
$total = 0;

$resultado = mysqli_query($conexion, "SELECT id FROM carrito WHERE usuario_id = $usuario_id");
$carrito = mysqli_fetch_assoc($resultado);

if ($carrito) {
    $id_carrito = $carrito['id'];

    
    $sql = "SELECT id_plato, COUNT(*) AS cantidad
            FROM detalle_carrito
            WHERE id_carrito = $id_carrito
            GROUP BY id_plato";
    $detalles = mysqli_query($conexion, $sql);

    while ($detalle = mysqli_fetch_assoc($detalles)) {
        $id_plato = $detalle['id_plato'];

        $res_plato = mysqli_query($conexion, "SELECT nombre, precio FROM platos WHERE id = $id_plato");
        $plato = mysqli_fetch_assoc($res_plato);

        $plato['id']       = $id_plato;
        $plato['cantidad'] = $detalle['cantidad'];
        $plato['subtotal'] = $plato['precio'] * $plato['cantidad'];

        $total += $plato['subtotal'];
        $platos_carrito[] = $plato;
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu Carrito - Trillinger</title>
    <link rel="stylesheet" href="../css/carrito.css">
    <script src="../js/main.js"></script>
</head>
<body>

    <header class="top-nav">
        <div class="nav-content">
            <h2 class="logo-text">Trillinger</h2>
            <a href="../auth/inicio.php">← Volver a la carta</a>
        </div>
    </header>

    <main class="contenedor">
        <h1>Tu pedido</h1>
        <p class="subtitulo">Revisá lo que elegiste antes de confirmar.</p>

        <?php if (empty($platos_carrito)): ?>
            <div class="vacio">
                <p>Tu carrito está vacío.</p>
                <a class="enlace-volver" href="../auth/inicio.php">Ver la carta</a>
            </div>
        <?php else: ?>

            <ul class="lista-carrito">
                <?php foreach ($platos_carrito as $plato): ?>
                    <li class="item-carrito">
                        <span class="item-nombre"><?php echo htmlspecialchars($plato['nombre']); ?></span>
                        <span class="item-cantidad">x<?php echo $plato['cantidad']; ?></span>
                        <span class="item-precio">$<?php echo $plato['subtotal']; ?></span>
                        <button type="button" class="btn-eliminar"
                                onclick="eliminarPlato(<?php echo $plato['id']; ?>)">Quitar</button>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="total-carrito">
                <span>Total</span>
                <strong>$<?php echo $total; ?></strong>
            </div>

            <form class="form-pedido" action="procesar_pedido.php" method="POST">
                <label>Tipo de entrega</label>
                <select name="tipo_entrega" id="tipo_entrega" onchange="mostrarDireccion()">
                    <option value="en_mesa">En mesa</option>
                    <option value="delivery">Delivery</option>
                </select>

                <div id="caja_direccion" style="display:none;">
                    <label>Dirección de entrega</label>
                    <input type="text" name="direccion" id="direccion"
                           placeholder="Calle, número, piso, localidad">
                </div>

                <button type="submit" class="btn-principal">Confirmar pedido</button>
            </form>

        <?php endif; ?>
    </main>

</body>
</html>