<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include("../config/conexion.php");

if (!isset($_SESSION["id_usuario"])) {
    header("Location: ../html/login.html");
    exit();
}

$sql = "SELECT * FROM platos";
$resultado = mysqli_query($conexion, $sql);

if (isset($_SESSION["rol"]) && $_SESSION["rol"] === "admin") {
    header("Location: ../admin/dashboard.php");
} else {
    include("../html/inicio_interfaz.php");
}
?>