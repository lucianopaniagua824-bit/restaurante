<?php
include("../config/conexion.php");

if ($_SERVER["REQUEST_METHOD"] != "POST") {
die("Método no permitido.");
}

$usuario = trim($_POST["usuario"] ?? "");
$email = trim($_POST["email"] ?? "");
$password = trim($_POST["password"] ?? "");

if (strlen($usuario) < 3 || strlen($usuario) > 30) {
die("El usuario debe tener entre 3 y 30 caracteres.");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
die("El email ingresado no es válido.");
}
if (strlen($password) < 8) {
die("La contraseña debe tener al menos 8 caracteres.");
}
$passwordHash = password_hash(
$password,
PASSWORD_DEFAULT
);
$sql = "
INSERT INTO usuarios
(nombre, email, password)
VALUES (?, ?, ?)
";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param(
$stmt,
"sss",
$usuario,
$email,
$passwordHash
);
mysqli_report(MYSQLI_REPORT_OFF);

if (mysqli_stmt_execute($stmt)) {
    echo "exitoso";
    exit();
} else {
    if (mysqli_errno($conexion) == 1062) {
        echo "No se pudo registrar el usuario.";
        echo "El correo electrónico o el nombre de usuario ya se encuentran registrados";
    } else {
        echo "Ocurrió un error inesperado.";
        echo  mysqli_error($conexion);
    }
}
?>