<?php
header("Location: ../html/login.html");
session_start();
session_destroy();
exit;
?>