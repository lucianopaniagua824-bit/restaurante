<?php
session_start();
include("../config/conexion.php");
;
if ($_SERVER["REQUEST_METHOD"] != "POST") {
die("Método no permitido.");
}
$usuario = trim($_POST["usuario"] ?? "");
$password = $_POST["password"] ?? "";
if ($usuario == "" || $password == "") {
die("Debe completar todos los campos.");
};

$sql = "
SELECT id, nombre, password, rol
FROM usuarios
WHERE nombre = ?
";

$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param(
$stmt,
"s",
$usuario
);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
if ($fila = mysqli_fetch_assoc($resultado)) {
if (password_verify(
$password,
$fila["password"]
)) {
session_regenerate_id(true);
$_SESSION["id_usuario"] = $fila["id"];
$_SESSION["usuario"] = $fila["nombre"];
$_SESSION["rol"] = $fila["rol"];

if( $fila["rol"] == "admin"){
echo "exito_admin";
exit;
}else{
    echo "exito_usuario";
}

} else {
echo "Usuario o contraseña incorrectos";
}
} else {
echo "Usuario o contraseña incorrectos";
}
mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>