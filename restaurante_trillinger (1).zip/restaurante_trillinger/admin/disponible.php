<?php
session_start();
include("../config/conexion.php");

// Si no es admin, lo mandamos al login
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "admin") {
    header("Location: ../html/login.html");
    exit();
}

$id = (int) $_POST["id"];

mysqli_query($conexion, "UPDATE platos SET disponible = NOT disponible WHERE id = $id");

header("Location: dashboard.php");
exit();
?>
