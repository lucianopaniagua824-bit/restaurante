<?php
session_start();
include("../config/conexion.php");

// Si no es admin, lo mandamos al login
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "admin") {
    header("Location: ../html/login.html");
    exit();
}

// 1. Tomamos el id del plato (con (int) nos aseguramos de que sea un número)
$id = (int) $_POST["id"];

// 2. Revisamos si el plato ya fue pedido alguna vez
//    (si fue pedido, la base de datos no deja borrarlo)
$consulta = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM detalle_pedido WHERE plato_id = $id");
$fila = mysqli_fetch_assoc($consulta);

if ($fila["total"] > 0) {
    header("Location: dashboard.php?error=pedido");
    exit();
}

// 3. Si nunca fue pedido, lo borramos
mysqli_query($conexion, "DELETE FROM platos WHERE id = $id");

// 4. Volvemos al panel
header("Location: dashboard.php");
exit();
?>
