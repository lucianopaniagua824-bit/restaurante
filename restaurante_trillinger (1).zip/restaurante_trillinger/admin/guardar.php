<?php
session_start();
include("../config/conexion.php");

// Si no es admin, lo mandamos al login
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "admin") {
    header("Location: ../html/login.html");
    exit();
}

// 1. Tomamos los datos que llegaron del formulario
$nombre      = trim($_POST["nombre"]);
$descripcion = trim($_POST["descripcion"]);
$precio      = $_POST["precio"];
$categoria   = $_POST["categoria"];
$imagen      = trim($_POST["imagen"]);

$sql = "INSERT INTO platos (categoria, nombre, descripcion, precio, imagen)
        VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conexion, $sql);

mysqli_stmt_bind_param($stmt, "sssds", $categoria, $nombre, $descripcion, $precio, $imagen);

mysqli_stmt_execute($stmt);

header("Location: dashboard.php");
exit();
?>
