<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include("../config/conexion.php");

// Si no es admin, lo mandamos al login
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "admin") {
    header("Location: ../html/login.html");
    exit();
}

// Pedimos todos los platos (los más nuevos primero)
$resultado = mysqli_query($conexion, "SELECT * FROM platos ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trillinger - Admin</title>
    <link rel="icon" type="image/jpeg" href="../upload/logo_trillinger.jpeg">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>

    <header class="top-nav">
        <div class="nav-content">
            <h2 class="logo-text">Trillinger</h2>
            <nav>
                <a href="../auth/logout.php">Cerrar sesión</a>
            </nav>
        </div>
    </header>

    <main class="main-container">

        <div class="header-carta">
            <span class="sub-tag">PANEL DE ADMINISTRACIÓN</span>
            <h1>Administrar la carta</h1>
            <p>Agregá platos nuevos y elegí cuáles ven los clientes.</p>
        </div>

        <!-- Mensaje si no se pudo eliminar (viene desde eliminar.php) -->
        <?php if (isset($_GET["error"])) { ?>
            <p style="color:red;">
                No se puede eliminar un plato que ya fue pedido. Usá "Ocultar a clientes".
            </p>
        <?php } ?>
<div class="seccion-titulo-contenedor">
    <h2>Agregar plato</h2>
</div>

<form action="guardar.php" method="POST" class="formulario-plato">

    <input type="text" name="nombre"
           placeholder="Nombre del plato" required>

    <input type="text" name="descripcion"
           placeholder="Descripción" required>

    <input type="number" name="precio"
           placeholder="Precio" step="0.01" required>

    <select name="categoria" required>
        <option value="entrada">Entrada</option>
        <option value="principal">Principal</option>
        <option value="ensaladas">Ensaladas</option>
        <option value="guarniciones">Guarniciones</option>
        <option value="postres">Postres</option>
    </select>

    <input type="text" name="imagen"
           placeholder="Link de la imagen" required>

    <button type="submit" class="agregar">
        Guardar
    </button>

</form>

        <!-- LISTA DE PLATOS -->
        <div class="seccion-titulo-contenedor">
            <h2>Platos de la carta</h2>
        </div>

        <div class="cartas">
            <?php while ($plato = mysqli_fetch_assoc($resultado)) { ?>

                <?php
                // Si la imagen es un link (http...) se usa tal cual.
                // Si no, es un archivo viejo guardado en la carpeta upload.
                if (str_starts_with($plato["imagen"], "http")) {
                    $imagen = $plato["imagen"];
                } else {
                    $imagen = "../upload/" . $plato["imagen"];
                }
                ?>

                <div class="Comida">
                    <div class="Imagen_Comida">
                        <img src="<?php echo $imagen; ?>" alt="Imagen">
                    </div>

                    <div class="card-body">
                        <h3 class="nombre_comida"><?php echo $plato["nombre"]; ?></h3>
                        <span class="descipcion_comida"><?php echo $plato["descripcion"]; ?></span>

                        <div class="card-footer-plato">
                            <span class="precio_comida">$<?php echo $plato["precio"]; ?></span>
                            <span><?php echo $plato["categoria"]; ?></span>
                        </div>

                        <!-- Botón para ocultar o mostrar el plato a los clientes -->
                        <form action="disponible.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo $plato["id"]; ?>">
                            <?php if ($plato["disponible"]) { ?>
                                <button type="submit" class="agregar">Ocultar a clientes</button>
                            <?php } else { ?>
                                <button type="submit" class="agregar">Mostrar a clientes (hoy está oculto)</button>
                            <?php } ?>
                        </form>

                        <!-- Botón para eliminar el plato (pide confirmación) -->
                        <form action="eliminar.php" method="POST"
                              onsubmit="return confirm('¿Seguro que querés eliminar este plato?');">
                            <input type="hidden" name="id" value="<?php echo $plato["id"]; ?>">
                            <button type="submit" class="agregar">Eliminar</button>
                        </form>
                    </div>
                </div>

            <?php } ?>
        </div>

    </main>

</body>
</html>
