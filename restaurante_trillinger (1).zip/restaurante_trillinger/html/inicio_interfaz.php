<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include("../config/conexion.php");

// Verificamos que el usuario haya iniciado sesión
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.html");
    exit();
}

$sesion = $_SESSION["id_usuario"];

// Traemos los platos
$sql = "SELECT * FROM platos ORDER BY id DESC";
$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trillinger - Inicio</title>
    <link rel="icon" type="image/jpeg" href="../upload/peque_logo_trillinger.png">
    <link rel="stylesheet" href="../css/interfaz.css">
    <script src="../js/main.js" defer></script>
</head>

<body>

<header class="top-nav">
    <div class="nav-content">
        <h2 class="logo-text">Trillinger</h2>

        <nav>
            <a href="#" class="active">La carta</a>
        </nav>

        <div class="nav-right">
            <a href="../carrito/carrito.php" class="enlace-carrito-top">
                <img src="../upload/carrito-de-compras.png" alt="Carrito">
                <span>Mi Carrito</span>
                <span id="contador_carrito"></span>
            </a>
        </div>
    </div>
</header>

<main class="main-container">

    <div class="header-carta">
        <span class="sub-tag">NUESTRA CARTA · OTOÑO / INVIERNO</span>
        <h1>Hoy, ¿qué te apetece?</h1>
        <p>Cocina honesta, productos de temporada y tus nuevos favoritos. Elige y disfruta.</p>
        <a href="../auth/logout.php">Cerrar Sesión</a>
    </div>

    <!-- FILTROS DE CATEGORÍAS -->

    <div class="seccion-titulo-contenedor">
        <h2>Lo mejor de esta temporada</h2>
    </div>

    <div class="filtros">

        <button type="button" class="filtro activo"
            onclick="filtrarPlatos('todos', this)">
            Todos
        </button>

        <button type="button" class="filtro"
            onclick="filtrarPlatos('entrada', this)">
            Entradas
        </button>

        <button type="button" class="filtro"
            onclick="filtrarPlatos('principal', this)">
            Principales
        </button>

        <button type="button" class="filtro"
            onclick="filtrarPlatos('ensaladas', this)">
            Ensaladas
        </button>

        <button type="button" class="filtro"
            onclick="filtrarPlatos('guarniciones', this)">
            Guarniciones
        </button>

        <button type="button" class="filtro"
            onclick="filtrarPlatos('postres', this)">
            Postres
        </button>

    </div>

    <!-- CUADRÍCULA DE PLATOS -->

    <div class="cartas">

        <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>

            <?php if ($fila["disponible"]) { ?>

                <?php
                $id = $fila["id"];
                $categoria = strtolower(trim($fila["categoria"]));
                ?>

                <div class="Comida"
                     data-categoria="<?php echo htmlspecialchars($categoria); ?>">

                    <div class="Imagen_Comida">
                        <img
                            src="../upload/<?php echo htmlspecialchars($fila["imagen"]); ?>"
                            alt="<?php echo htmlspecialchars($fila["nombre"]); ?>">
                    </div>

                    <div class="card-body">

                        <h3 class="nombre_comida">
                            <?php echo htmlspecialchars($fila["nombre"]); ?>
                        </h3>

                        <span class="descipcion_comida">
                            <?php echo htmlspecialchars($fila["descripcion"]); ?>
                        </span>

                        <div class="card-footer-plato">

                            <span class="precio_comida">
                                $<?php echo htmlspecialchars($fila["precio"]); ?>
                            </span>

                            <div class="controles-cantidad">

                                <button type="button" class="resta"
                                    onclick="cantCom('-', '<?php echo $id; ?>')">
                                    -
                                </button>

                                <input type="text"
                                    id="cant_<?php echo $id; ?>"
                                    value="1" readonly>

                                <button type="button" class="suma"
                                    onclick="cantCom('+', '<?php echo $id; ?>')">
                                    +
                                </button>

                            </div>
                        </div>

                        <button type="button" class="agregar"
                            onclick="agregarCarrito('<?php echo $sesion; ?>', '<?php echo $id; ?>')">
                            Agregar
                        </button>

                        <p id="p_res<?php echo $id; ?>"
                           class="mensaje-agregado"></p>

                    </div>
                </div>

            <?php } ?>

        <?php } ?>

    </div>

</main>

<!-- FILTRADO CON JAVASCRIPT -->

<script>

function filtrarPlatos(categoria, boton) {

    // Obtenemos todas las tarjetas
    let platos = document.querySelectorAll(".Comida");

    // Obtenemos todos los botones
    let botones = document.querySelectorAll(".filtro");

    // Cambiamos el botón activo
    botones.forEach(function(b) {
        b.classList.remove("activo");
    });

    boton.classList.add("activo");

    // Recorremos cada plato
    platos.forEach(function(plato) {

        let categoriaPlato = plato.dataset.categoria.trim().toLowerCase();

        if (categoria === "todos" || categoriaPlato === categoria) {
            plato.style.display = "";
        } else {
            plato.style.display = "none";
        }

    });

}

</script>

</body>
</html>