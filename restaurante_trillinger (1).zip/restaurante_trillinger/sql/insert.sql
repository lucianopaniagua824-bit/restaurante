INSERT INTO platos (categoria, nombre, descripcion, precio, disponible, imagen) VALUES

('entrada', 'Empanadas de Carne',
'Empanadas caseras de carne cortada a cuchillo, al horno.',
4500.00, TRUE, 'empanadas_carne.jpg'),

('entrada', 'Provoleta Rústica',
'Queso provolone fundido con tomates cherry y orégano.',
7800.00, TRUE, 'provoleta.jpg'),

('entrada', 'Bruschettas de Jamón Crudo',
'Pan tostado con queso crema, jamón crudo y rúcula.',
7900.00, TRUE, 'bruschettas_jamon.jpg'),

('entrada', 'Rabas a la Romana',
'Anillos de calamar rebozados y fritos con limón.',
11500.00, TRUE, 'rabas.jpg'),

('entrada', 'Bastoncitos de Muzzarella',
'Bastones de queso empanados con salsa marinera.',
6500.00, TRUE, 'bastoncitos_muzzarella.jpg'),

('entrada', 'Tortilla Española',
'Clásica tortilla de papas con cebolla y un punto jugoso.',
6900.00, TRUE, 'tortilla_espanola.jpg'),

('entrada', 'Champiñones al Ajillo',
'Hongos salteados en aceite de oliva, ajo y perejil.',
7400.00, TRUE, 'champinones_ajillo.jpg'),

('entrada', 'Papas Bravas',
'Cubos de papa dorados con salsa picante y alioli.',
5800.00, TRUE, 'papas_bravas.jpg'),

('entrada', 'Croquetas de Acelga',
'Bocaditos crocantes de acelga acompañados de salsa blanca.',
5300.00, TRUE, 'croquetas_acelga.jpg'),

('entrada', 'Sopa de Calabaza',
'Crema de calabaza con semillas tostadas y un toque de crema.',
5100.00, TRUE, 'sopa_calabaza.jpg'),

('principal', 'Bife de Chorizo con Papas',
'Clásico corte argentino acompañado de papas fritas.',
16500.00, TRUE, 'bife_chorizo.jpg'),

('principal', 'Milanesa Napolitana',
'Milanesa gratinada con salsa de tomate, jamón y muzzarella.',
14200.00, TRUE, 'milanesa_napolitana.jpg'),

('principal', 'Ñoquis Caseros a la Caruso',
'Ñoquis de papa con salsa de crema, champiñones y jamón.',
12500.00, TRUE, 'noquis_caruso.jpg'),

('principal', 'Asado de Tira',
'Asado cocido a las brasas acompañado de chimichurri.',
17800.00, TRUE, 'asado_tira.jpg'),

('principal', 'Suprema a la Suiza',
'Pechuga rebozada con salsa blanca y queso gratinado.',
13100.00, TRUE, 'suprema_suiza.jpg'),

('principal', 'Ravioles de Verdura y Ricota',
'Ravioles caseros acompañados de salsa de tomate.',
12200.00, TRUE, 'ravioles_verdura.jpg'),

('principal', 'Salmón Rosado al Limón',
'Filet de salmón a la plancha con manteca de hierbas y puré.',
22000.00, TRUE, 'salmon_rosado.jpg'),

('principal', 'Bondiola de Cerdo',
'Bondiola cocida lentamente con papas rústicas.',
15800.00, TRUE, 'bondiola_cerdo.jpg'),

('principal', 'Risotto de Hongos',
'Arroz cremoso con hongos de temporada y queso parmesano.',
13800.00, TRUE, 'risotto_hongos.jpg'),

('principal', 'Hamburguesa Completa',
'Hamburguesa de carne con cheddar, panceta, huevo y papas.',
11800.00, TRUE, 'hamburguesa_gourmet.jpg'),


('ensaladas', 'Ensalada Caesar con Pollo',
'Lechuga romana, pollo grillado, crutones y queso parmesano.',
9800.00, TRUE, 'ensalada_caesar.jpg'),

('ensaladas', 'Ensalada Caprese',
'Tomate, muzzarella fresca, albahaca y aceite de oliva.',
9500.00, TRUE, 'ensalada_caprese.jpg'),

('ensaladas', 'Ensalada Completa',
'Lechuga, tomate, zanahoria, cebolla y huevo duro.',
7200.00, TRUE, 'ensalada_completa.jpg'),

('ensaladas', 'Ensalada Griega',
'Tomate, pepino, queso feta, aceitunas y cebolla morada.',
9100.00, TRUE, 'ensalada_griega.jpg'),

('ensaladas', 'Ensalada de Atún',
'Lechuga, tomate, atún, huevo y choclo.',
8800.00, TRUE, 'ensalada_atun.jpg'),

('ensaladas', 'Ensalada Waldorf',
'Manzana, apio, nueces y salsa cremosa.',
8100.00, TRUE, 'ensalada_waldorf.jpg'),

('ensaladas', 'Ensalada de Quinoa',
'Quinoa, palta, tomates cherry, pepino y limón.',
9600.00, TRUE, 'ensalada_quinoa.jpg'),

('ensaladas', 'Ensalada Rúcula y Parmesano',
'Rúcula fresca, parmesano, tomates cherry y aceto.',
8400.00, TRUE, 'ensalada_rucula.jpg'),

('ensaladas', 'Ensalada de Pollo',
'Pollo grillado, hojas verdes, zanahoria y tomate.',
9900.00, TRUE, 'ensalada_pollo.jpg'),

('ensaladas', 'Ensalada Mediterránea',
'Hojas verdes, aceitunas, morrones asados y queso.',
9400.00, TRUE, 'ensalada_mediterranea.jpg'),


('guarniciones', 'Papas Fritas',
'Porción de papas fritas clásicas y crocantes.',
5200.00, TRUE, 'papas_fritas.jpg'),

('guarniciones', 'Puré de Papa',
'Puré cremoso de papas naturales con manteca.',
4800.00, TRUE, 'pure_papa.jpg'),

('guarniciones', 'Puré de Calabaza',
'Puré suave de calabaza asada.',
4900.00, TRUE, 'pure_calabaza.jpg'),

('guarniciones', 'Papas Rústicas',
'Gajos de papa al horno con romero y ajo.',
5400.00, TRUE, 'papas_rusticas.jpg'),

('guarniciones', 'Verduras Asadas',
'Zanahoria, zucchini, berenjena y morrón al horno.',
6100.00, TRUE, 'verduras_asadas.jpg'),

('guarniciones', 'Arroz Blanco',
'Arroz blanco cocido y condimentado suavemente.',
4200.00, TRUE, 'arroz_blanco.jpg'),

('guarniciones', 'Batatas Fritas',
'Bastones de batata fritos y crocantes.',
5800.00, TRUE, 'batatas_fritas.jpg'),

('guarniciones', 'Papas Noisette',
'Pequeñas esferas de papa doradas y crocantes.',
5500.00, TRUE, 'papas_noisette.jpg'),

('guarniciones', 'Ensalada Mixta',
'Porción de lechuga, tomate y cebolla.',
4500.00, TRUE, 'ensalada_mixta_chica.jpg'),

('guarniciones', 'Espinacas a la Crema',
'Espinacas salteadas con crema y queso gratinado.',
5900.00, TRUE, 'espinacas_crema.jpg'),


('postres', 'Flan Casero Mixto',
'Flan de vainilla acompañado de dulce de leche y crema.',
5500.00, TRUE, 'flan_mixto.jpg'),

('postres', 'Volcán de Chocolate',
'Bizcocho tibio de chocolate con centro fundido y helado.',
6800.00, TRUE, 'volcan_chocolate.jpg'),

('postres', 'Tiramisú',
'Postre italiano con vainillas, café, mascarpone y cacao.',
6200.00, TRUE, 'tiramisu.jpg'),

('postres', 'Cheesecake de Frutos Rojos',
'Tarta de queso con base de galletas y frutos rojos.',
6500.00, TRUE, 'cheesecake_frutos_rojos.jpg'),

('postres', 'Brownie con Helado',
'Brownie de chocolate con nueces y helado de vainilla.',
6100.00, TRUE, 'brownie_helado.jpg'),

('postres', 'Helado de Dos Bochas',
'Helado artesanal de dos sabores a elección.',
5000.00, TRUE, 'helado_dos_bochas.jpg'),

('postres', 'Queso y Dulce',
'Queso fresco acompañado de dulce de batata o membrillo.',
4900.00, TRUE, 'queso_y_dulce.jpg'),

('postres', 'Panqueque de Dulce de Leche',
'Panqueque casero relleno de dulce de leche.',
5300.00, TRUE, 'panqueque_dl.jpg'),

('postres', 'Lemon Pie',
'Tarta de limón con merengue italiano.',
5700.00, TRUE, 'lemon_pie.jpg'),

('postres', 'Chocotorta',
'Postre argentino de chocolinas, dulce de leche y queso crema.',5600.00, TRUE, 'chocotorta.jpg');