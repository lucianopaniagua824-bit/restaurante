function enviarRegistro() {
    let formulario = document.getElementById("formRegistro");
    let datosFormulario = new FormData(formulario);
    let etiquetaRespuesta = document.getElementById("respuesta");

    fetch("../auth/procesar_registro.php", {
        method: "POST",
        body: datosFormulario
    })
    .then(respuestaServidor => respuestaServidor.text()) 
    .then(mensajePHP => {
        etiquetaRespuesta.innerText = mensajePHP;

        if (mensajePHP.includes("exitoso")) {
            etiquetaRespuesta.style.color = "green";
            etiquetaRespuesta.style.backgroundColor = "#09f1a4";
            etiquetaRespuesta.style.border = "1px solid #292424"

            
            setTimeout(() => {
                window.location.href = "login.html"; 
            }, 1500);
        } else {
            etiquetaRespuesta.style.color = "red";
            etiquetaRespuesta.style.backgroundColor = "#f8d7da";
            etiquetaRespuesta.style.border = "1px solid #292424";
        }
    });
}

function enviarLogin() {
    let formulario_login = document.getElementById("formRegistro_login");
    let datosFormulario_login = new FormData(formulario_login);
    let etiquetaRespuesta_login = document.getElementById("respuesta_login"); 

    fetch("../auth/validarLogin.php", {
        method: "POST",
        body: datosFormulario_login
    })
    .then(respuestaServidor => respuestaServidor.text()) 
    .then(mensajePHP => {
        etiquetaRespuesta_login.innerText = mensajePHP;

        etiquetaRespuesta_login.style.color = "#721c24";          
        etiquetaRespuesta_login.style.backgroundColor = "#f8d7da";
        etiquetaRespuesta_login.style.border = "1px solid #141414"; 
        etiquetaRespuesta_login.style.padding = "10px";          
        etiquetaRespuesta_login.style.borderRadius = "5px";      
        etiquetaRespuesta_login.style.marginTop = "10px"; 


        if (mensajePHP.includes("admin")) {
            etiquetaRespuesta_login.style.color = "#155724";
            etiquetaRespuesta_login.style.backgroundColor = "#d4edda";
            etiquetaRespuesta_login.style.border = "1px solid #121312";
            
            setTimeout(() => {
                window.location.href = "../auth/inicio.php";
            }, 1500);

        }else if (mensajePHP.includes("usuario")){
            etiquetaRespuesta_login.style.color = "#155724";
            etiquetaRespuesta_login.style.backgroundColor = "#d4edda";
            etiquetaRespuesta_login.style.border = "1px solid #080808";
            
            setTimeout(() => {
                window.location.href = "../auth/inicio.php";
            }, 1500);
        }
    });
}


function cantCom(operacion, id) {
  let idpal = "cant_" + id;
  let input = document.getElementById(idpal);

  if (operacion === "+") {
    input.value++;
  } else if (input.value > 1) {
    input.value--;
  }
}

function agregarCarrito(usuario_id, plato_id){
    let cant = "cant_" + plato_id;
    let cantidadInput = document.getElementById(cant);
    let cantidad = cantidadInput ? cantidadInput.value : 1; 
    let p = document.getElementById('p_res' + plato_id);
    
    let datos = new FormData();
    datos.append('usuario_id', usuario_id);
    datos.append('plato_id', plato_id);
    datos.append('cantidad', cantidad);

    fetch('../carrito/agregarCarrito.php', {
        method: 'POST',
        body: datos
    })
    .then(response => response.text())
    .then(respuesta => {
        if(p) {
            p.style.fontSize = "12px";
            if(respuesta.trim() === "ok"){
                p.innerHTML = "¡Lo agregaste al carrito!";
            } else {
                p.innerHTML = "Hubo un error al agregar.";
            }
            setTimeout(() => {
            p.innerHTML = '';
        }, 1500);
        }
    })
    .catch(error => console.error('Error:', error));
}

function eliminarPlato(plato_id) {
    let datos = new FormData();
    datos.append('id_plato', plato_id);

    fetch('../carrito/eliminar_plato.php', {
        method: 'POST',
        body: datos
    })
    .then(response => response.text())
    .then(respuesta => {
        if (respuesta.trim() === "ok") {
            location.reload();
        } else {
            alert("Hubo un error al eliminar.");
        }
    })
    .catch(error => console.error('Error:', error));
}

function mostrarDireccion() {
    let tipo = document.getElementById("tipo_entrega").value;
    let caja = document.getElementById("caja_direccion");
    let input = document.getElementById("direccion");

    if (tipo === "delivery") {
        caja.style.display = "block";
        input.required = true;  
    } else {
        caja.style.display = "none";
        input.required = false;
        input.value = "";
    }
}